<?php
    defined('myeshop') or header('Location: ../not_found.php');
    function clear_string($cl_str)
    {
        $cl_str = strip_tags($cl_str);
        $cl_str = mysql_real_escape_string($cl_str);
        $cl_str = trim($cl_str);
        return $cl_str;
    }
?>