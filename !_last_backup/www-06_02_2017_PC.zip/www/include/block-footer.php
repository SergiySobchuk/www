<?php
	defined('myeshop') or header('Location: ../not_found.php');
?>
<div id="block-footer">
    <div id="bottom-line"></div>
    <div id="footer-phone">
        <h4>Служба підтримки</h4>
        <h3>8(800) 937-99-92</h3>
        <p>
            Режим роботи:<br />
            Будні дні: з 9:00 до 18:00<br />
            Субота, Неділя - вихідні
        </p>
    </div>
    <div class="footer-list">
        <p>Сервіс і допомога</p>
        <ul type="none">
            <li>
                <a href="">Як зробити замовлення</a><br />
                <a href="">Спосіб оплати</a><br />
                <a href="">Повернення</a><br />
                <a href="">Публічна оферта</a>
            </li>
        </ul>
    </div>   
    <div class="footer-list">
        <p>Про компанію;</p>
        <ul type="none">
            <li>
                <a href="">Про нас</a><br />
                <a href="">Вакансії</a><br />
                <a href="">Партнерам</a><br />
                <a href="">Контакти</a>
            </li>
        </ul>
    </div> 
    <div class="footer-list">
        <p>Навігація</p>
        <ul type="none">
            <li>
                <a href="index.php">Головна сторінка</a><br />
                <a href="">Зворотній звязок</a>
            </li>
        </ul>
         <p>Розповісти про сайт</p>

        <script type="text/javascript">
            (function() {
                if (window.pluso)if (typeof window.pluso.start == "function") return;
                var d = document, s = d.createElement('script'), g = 'getElementsByTagName';
                s.type = 'text/javascript'; s.charset='UTF-8'; s.async = true;
                s.src = ('https:' == window.location.protocol ? 'https' : 'http')  + '://share.pluso.ru/pluso-like.js';
                var h=d[g]('head')[0] || d[g]('body')[0];
                h.appendChild(s);
            });
        </script>
        <div class="pluso" data-options="small,square,line,horizontal,nocounter,theme=08" data-services="vkontakte,odnoklassniki,facebook,twitter,google,moimir,email,print" data-background="#ebebeb"></div>

    </div>

</div>



