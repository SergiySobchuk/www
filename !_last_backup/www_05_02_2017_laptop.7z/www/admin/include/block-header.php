<?php
	defined('myeshop') or header('Location: ../not_found.php');
?>
<div id="block-header">
    <div id="block-header1">
        <h3>IT-SHOP. Панель керування</h3>
        <p id="link-nav"><?php
	                       echo $_SESSION['urlpage'];
                        ?>
        </p>
    </div>
    
    <div id="block-header2">
        <p align="right"><a href="administrators.php">Адміністратори</a> | <a href="?logout">ВИХІД</a></p>
        <p align="right">Ви - 5354353452345<span></span></p>
    </div>
</div>
<div id="left-nav">
    <ul>
        <li><a href="orders.php">Замовлення</a></li>
        <li><a href="tovar.php?cat=all">Товари</a></li>
        <li><a href="reviews.php">Відгуки</a></li>
        <li><a href="category.php">Категорії</a></li>
        <li><a href="clients.php">Клієнти</a></li>
        <li><a href="news.php">Новини</a></li>
    </ul>
</div>
