<?php
    echo
    '
        <img src="./images/not-found.png"/>
    ';
?>